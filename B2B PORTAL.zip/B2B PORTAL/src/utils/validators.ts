export const required = (v: string | number) => (v === undefined || v === null || String(v).trim() === '') ? 'Required' : null;
export const isNumber = (v: string) => /^-?\d*(\.\d+)?$/.test(v);
export const numberRequired = (v: string) => isNumber(v) && v.trim() !== '' ? null : 'Numeric value required';
export const positive = (n: number) => (isNaN(n) || n <= 0) ? 'Must be greater than 0' : null;
export const phone = (v: string) => /^\+?[0-9\s-]{7,15}$/.test(v) ? null : 'Invalid phone';
