// This file is intentionally left blank.
export {}; // ensure this file is a module (fixes TS1208 'isolatedModules' error)