import React from 'react';
import Sidebar from '../components/shared/Sidebar';
import styles from './DashboardLayout.module.css';

interface DashboardLayoutProps {
  children: React.ReactNode;
  className?: string;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ 
  children, 
  className 
}) => {
  return (
    <div className={`${styles.layout} ${className || ''}`}>
      <Sidebar className={styles.sidebar} />
      <div className={styles.mainContent}>
        {/* header removed */}
        <main className={styles.content}>
          {/* Notifications are shown only on dashboard pages (moved to RoleBasedDashboard) */}
          {children}
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;