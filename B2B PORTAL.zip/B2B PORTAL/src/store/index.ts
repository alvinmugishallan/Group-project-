import { createStore, applyMiddleware } from 'redux';
import thunk, { ThunkMiddleware } from 'redux-thunk';
import { AnyAction } from 'redux';
import rootReducer, { RootState } from './reducers';

// cast thunk via unknown to satisfy TS type-checker
const store = createStore(
  rootReducer,
  applyMiddleware(thunk as unknown as ThunkMiddleware<RootState, AnyAction>)
);

export default store;