import { combineReducers } from 'redux';

// Basic state interfaces
interface AuthState {
  isAuthenticated: boolean;
  loading: boolean;
}

interface UserState {
  userData: null | {
    id: string;
    name: string;
    role: 'customer' | 'ceo' | 'manager' | 'sales';
  };
}

// Initial states
const initialAuthState: AuthState = {
  isAuthenticated: false,
  loading: false
};

const initialUserState: UserState = {
  userData: null
};

// Reducers
const authReducer = (state = initialAuthState, action: any): AuthState => {
  switch (action.type) {
    case 'LOGIN_REQUEST':
      return { ...state, loading: true };
    case 'LOGIN_SUCCESS':
      return { ...state, isAuthenticated: true, loading: false };
    case 'LOGOUT':
      return initialAuthState;
    default:
      return state;
  }
};

const userReducer = (state = initialUserState, action: any): UserState => {
  switch (action.type) {
    case 'SET_USER_DATA':
      return { ...state, userData: action.payload };
    case 'CLEAR_USER_DATA':
      return initialUserState;
    default:
      return state;
  }
};

// Combine reducers
const rootReducer = combineReducers({
  auth: authReducer,
  user: userReducer
});

export type RootState = ReturnType<typeof rootReducer>;
export default rootReducer;