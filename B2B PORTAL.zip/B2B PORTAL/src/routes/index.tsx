import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from '../components/auth/Login';
import SignUp from '../components/auth/SignUp';
import DashboardLayout from '../layouts/DashboardLayout';
import RoleBasedDashboard from '../components/dashboards/RoleBasedDashboard';
import Products from '../components/products/Products';
import Support from '../components/dashboards/customer/Support';
import Orders from '../components/orders/Orders';

const AppRoutes: React.FC = () => {
  return (
    <Router>
      <Routes>
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<SignUp />} />
        <Route
          path="/dashboard"
          element={
            <DashboardLayout>
              <RoleBasedDashboard />
            </DashboardLayout>
          }
        />
        <Route
          path="/products"
          element={
            <DashboardLayout>
              <Products />
            </DashboardLayout>
          }
        />
        <Route
          path="/orders"
          element={
            <DashboardLayout>
              <Orders />
            </DashboardLayout>
          }
        />
        <Route
          path="/support"
          element={
            <DashboardLayout>
              <Support />
            </DashboardLayout>
          }
        />
        <Route path="/" element={<Navigate to="/login" replace />} />
      </Routes>
    </Router>
  );
};

export default AppRoutes;