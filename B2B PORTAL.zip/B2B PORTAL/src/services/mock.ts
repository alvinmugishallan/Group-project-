// Simple in-memory mock data layer with localStorage persistence
export type ID = string;

export interface Produce {
  id: ID; name: string; type: string; branch: string; tonnage: number; costPerTonne: number; dealerName: string; contact: string; sellingPrice: number; datetime: string;
}
export interface Sale {
  id: ID; produceName: string; tonnage: number; unitPrice: number; total: number; buyerName: string; buyerContact: string; agentName: string; datetime: string;
}
export interface CreditSale {
  id: ID; buyer: { name: string; nationalId: string; location: string; phone: string; }; produceName: string; tonnage: number; amount: number; dueDate: string; createdAt: string; status: 'due'|'overdue'|'paid';
}
export interface StockItem { produceName: string; currentQty: number; reorderLevel: number; lastUpdated: string; }

const KEY = 'b2b-mock-store-v1';

export interface Store {
  procurement: Produce[];
  sales: Sale[];
  credit: CreditSale[];
  stock: StockItem[];
}

const defaultStore: Store = {
  procurement: [],
  sales: [],
  credit: [],
  stock: [],
};

function load(): Store {
  try { const raw = localStorage.getItem(KEY); if (!raw) return { ...defaultStore }; return JSON.parse(raw); } catch { return { ...defaultStore }; }
}
function save(s: Store) { localStorage.setItem(KEY, JSON.stringify(s)); }

function uid(): ID { return Math.random().toString(36).slice(2) + Date.now().toString(36); }

let state: Store = load();

export const mock = {
  get: (): Store => state,
  addProcurement: (p: Omit<Produce,'id'>) => {
    const rec: Produce = { ...p, id: uid() };
    state.procurement.unshift(rec);
    // update stock
    const stock = state.stock.find(s=>s.produceName===rec.name);
    if (stock) { stock.currentQty += rec.tonnage; stock.lastUpdated = new Date().toISOString(); }
    else { state.stock.push({ produceName: rec.name, currentQty: rec.tonnage, reorderLevel: 2, lastUpdated: new Date().toISOString() }); }
    save(state); return rec;
  },
  addSale: (s: Omit<Sale,'id'|'total'>) => {
    const rec: Sale = { ...s, id: uid(), total: s.tonnage * s.unitPrice };
    state.sales.unshift(rec);
    // reduce stock
    const stock = state.stock.find(x=>x.produceName===rec.produceName);
    if (stock) { stock.currentQty -= rec.tonnage; stock.lastUpdated = new Date().toISOString(); }
    save(state); return rec;
  },
  addCredit: (c: Omit<CreditSale,'id'|'status'|'createdAt'>) => {
    const status: CreditSale['status'] = new Date(c.dueDate) < new Date() ? 'overdue' : 'due';
    const rec: CreditSale = { ...c, id: uid(), status, createdAt: new Date().toISOString() };
    state.credit.unshift(rec); save(state); return rec;
  },
  markCreditPaid: (id: ID) => { const it = state.credit.find(x=>x.id===id); if (it) { it.status='paid'; save(state);} },
  reset: () => { state = { ...defaultStore }; save(state); },
};
