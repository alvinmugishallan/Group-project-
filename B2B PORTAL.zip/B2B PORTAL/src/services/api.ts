import axios from 'axios';

const API_BASE = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000';

const client = axios.create({
  baseURL: `${API_BASE}/api`,
  timeout: 10000,
});

// attach access token automatically
client.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken');
  if (token && config.headers) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

// response interceptor: try refresh once on 401
client.interceptors.response.use(
  (res) => res,
  async (err) => {
    const original = err.config;
    if (err.response?.status === 401 && !original?._retry) {
      original._retry = true;
      const refresh = localStorage.getItem('refreshToken');
      if (refresh) {
        try {
          const { data } = await axios.post(`${API_BASE}/api/auth/refresh`, { token: refresh });
          localStorage.setItem('accessToken', data.accessToken);
          original.headers = original.headers || {};
          original.headers.Authorization = `Bearer ${data.accessToken}`;
          return client(original);
        } catch (e) {
          localStorage.removeItem('accessToken');
          localStorage.removeItem('refreshToken');
          window.location.href = '/login';
          return Promise.reject(e);
        }
      }
    }
    return Promise.reject(err);
  }
);

export async function fetchData<T = any>(path: string): Promise<T> {
  try {
    const response = await client.get<T>(path);
    return response.data;
  } catch (err: unknown) {
    if (axios.isAxiosError(err)) {
      const msg = err.message || (err.response ? `HTTP ${err.response.status}` : 'Axios error');
      throw new Error(msg);
    }
    if (err instanceof Error) {
      throw err;
    }
    throw new Error('Unknown error');
  }
}

// Generic request helpers
export const get = async <T = any>(endpoint: string): Promise<T> => {
  const response = await client.get<T>(endpoint);
  return response.data;
};

export const post = async <T = any>(endpoint: string, data?: any): Promise<T> => {
  const response = await client.post<T>(endpoint, data);
  return response.data;
};

export const put = async <T = any>(endpoint: string, data?: any): Promise<T> => {
  const response = await client.put<T>(endpoint, data);
  return response.data;
};

export const del = async <T = any>(endpoint: string): Promise<T> => {
  const response = await client.delete<T>(endpoint);
  return response.data;
};

export default client;