export const login = async (email: string, password: string) => {
    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email, password }),
        });

        if (!response.ok) {
            throw new Error('Login failed');
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error during login:', error);
        throw error;
    }
};

export const signUp = async (userData: {
    companyName: string;
    contactPersonName: string;
    email: string;
    phoneNumber: string;
    password: string;
    businessType: string;
}) => {
    try {
        const response = await fetch('/api/auth/signup', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(userData),
        });

        if (!response.ok) {
            throw new Error('Sign up failed');
        }

        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error during sign up:', error);
        throw error;
    }
};