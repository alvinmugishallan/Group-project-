import React from 'react';
import { mock, Sale } from '../../services/mock';

const SalesTable: React.FC = () => {
  const store = mock.get();
  const rows = store.sales;

  return (
    <div className="card p-6" style={{marginTop:24}}>
      <div className="flex justify-between items-center">
        <h3 className="h3">Sales Records</h3>
        <span className="subtle">{rows.length} items</span>
      </div>
      <div className="divider mt-4"/>
      <div style={{overflowX:'auto', marginTop:16}}>
        <table className="table" style={{width:'100%', borderCollapse:'separate', borderSpacing:0}}>
          <thead>
            <tr style={{textAlign:'left', color:'var(--muted)'}}>
              <th style={{padding:'10px 12px'}}>Date</th>
              <th style={{padding:'10px 12px'}}>Produce</th>
              <th style={{padding:'10px 12px'}}>Tonnage</th>
              <th style={{padding:'10px 12px'}}>Unit price</th>
              <th style={{padding:'10px 12px'}}>Total</th>
              <th style={{padding:'10px 12px'}}>Buyer</th>
              <th style={{padding:'10px 12px'}}>Agent</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r: Sale)=> (
              <tr key={r.id} className="surface" style={{borderRadius:12}}>
                <td style={{padding:'10px 12px'}}>{new Date(r.datetime).toLocaleString()}</td>
                <td style={{padding:'10px 12px'}}>{r.produceName}</td>
                <td style={{padding:'10px 12px'}}>{r.tonnage}</td>
                <td style={{padding:'10px 12px'}}>{r.unitPrice}</td>
                <td style={{padding:'10px 12px'}}>{r.total}</td>
                <td style={{padding:'10px 12px'}}>{r.buyerName}</td>
                <td style={{padding:'10px 12px'}}>{r.agentName}</td>
              </tr>
            ))}
            {rows.length===0 && (
              <tr><td colSpan={7} className="subtle" style={{padding:'12px'}}>No data yet. Add a sale above.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default SalesTable;
