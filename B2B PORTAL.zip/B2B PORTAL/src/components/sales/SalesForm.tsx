import React, { useState } from 'react';
import { mock } from '../../services/mock';
import { numberRequired, positive, required } from '../../utils/validators';

const SalesForm: React.FC = () => {
  const [form, setForm] = useState({
    produceName:'', tonnage:'', unitPrice:'', buyerName:'', buyerContact:'', agentName:'', datetime: new Date().toISOString().slice(0,16)
  });
  const [error, setError] = useState<string|null>(null);
  const update = (k:string, v:string) => setForm(s=>({...s,[k]:v}));

  const submit = (e: React.FormEvent) => {
    e.preventDefault(); setError(null);
    const errs = [required(form.produceName), numberRequired(form.tonnage), numberRequired(form.unitPrice)];
    if (errs.find(Boolean)) { setError('Please fill required fields with valid numbers.'); return; }
    const tonnage = parseFloat(form.tonnage); const unitPrice = parseFloat(form.unitPrice);
    const posErr = positive(tonnage) || positive(unitPrice);
    if (posErr) { setError(posErr); return; }
    mock.addSale({ produceName: form.produceName, tonnage, unitPrice, buyerName: form.buyerName, buyerContact: form.buyerContact, agentName: form.agentName, datetime: new Date(form.datetime).toISOString() });
    setForm({ produceName:'', tonnage:'', unitPrice:'', buyerName:'', buyerContact:'', agentName:'', datetime: new Date().toISOString().slice(0,16) });
  };

  return (
    <div className="card p-6" style={{maxWidth:1200, margin:'0 auto'}}>
      <h2 className="h2">Record Sale</h2>
      <p className="subtle">Capture a sale and automatically update stock.</p>
      <form className="flex flex-col gap-4 mt-6" onSubmit={submit}>
        {error && <div className="error" role="alert">{error}</div>}
        <div className="flex gap-6">
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="produceName">Produce name</label>
            <input id="produceName" className="input" value={form.produceName} onChange={e=>update('produceName', e.target.value)} />
          </div>
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="tonnage">Tonnage (t)</label>
            <input id="tonnage" className="input" value={form.tonnage} onChange={e=>update('tonnage', e.target.value)} />
          </div>
        </div>
        <div className="flex gap-6">
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="unitPrice">Unit price</label>
            <input id="unitPrice" className="input" value={form.unitPrice} onChange={e=>update('unitPrice', e.target.value)} />
          </div>
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="buyerName">Buyer name</label>
            <input id="buyerName" className="input" value={form.buyerName} onChange={e=>update('buyerName', e.target.value)} />
          </div>
        </div>
        <div className="flex gap-6">
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="buyerContact">Buyer contact</label>
            <input id="buyerContact" className="input" value={form.buyerContact} onChange={e=>update('buyerContact', e.target.value)} />
          </div>
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="agentName">Sales agent</label>
            <input id="agentName" className="input" value={form.agentName} onChange={e=>update('agentName', e.target.value)} />
          </div>
        </div>
        <div className="form-row">
          <label className="subtle" htmlFor="datetime">Date/time</label>
          <input id="datetime" type="datetime-local" className="input" value={form.datetime} onChange={e=>update('datetime', e.target.value)} />
        </div>
        <div className="btn-row">
          <button className="button btn-primary" type="submit">Save sale</button>
        </div>
      </form>
    </div>
  );
};

export default SalesForm;
