import React, { useEffect, useState } from 'react';
import { get } from '../../../services/api';

const SalesDashboard: React.FC = () => {
    const [loading, setLoading] = useState(true);
    const [overview, setOverview] = useState<any>(null);

    useEffect(() => {
        let mounted = true;
        (async () => {
            try {
                const data = await get('/sales/overview');
                if (!mounted) return;
                setOverview(data);
            } catch (e) {
                // ignore
            } finally {
                if (mounted) setLoading(false);
            }
        })();
        return () => { mounted = false; };
    }, []);

    if (loading) return <div>Loading sales data...</div>;

    return (
        <div className="sales-dashboard">
            <h1 style={{marginBottom:12}}>Sales Dashboard</h1>

            <section style={{marginBottom:18}}>
                <h2 style={{marginBottom:8}}>Targets & Performance</h2>
                <div className="dashboard-grid">
                    <div className="card-dark">
                        <h3>Monthly Sales Target</h3>
                        <div style={{marginTop:8,fontSize:20,fontWeight:800}}>{overview?.monthlySalesTarget ?? '—'}</div>
                    </div>
                    <div className="card-dark">
                        <h3>Commission Earned</h3>
                        <div style={{marginTop:8,fontSize:20,fontWeight:700}}>{overview?.commissionEarned ?? '—'}</div>
                    </div>
                    <div className="card-dark">
                        <h3>Orders This Week</h3>
                        <div style={{marginTop:8}}>{overview?.ordersThisWeek ?? '—'}</div>
                    </div>
                </div>
            </section>

            <section>
                <h2 style={{marginBottom:8}}>Top Customers</h2>
                <div className="card-dark">
                    <ul>
                        {(overview?.topCustomers || []).map((c: any) => (
                            <li key={c.id} style={{marginBottom:6}}>{c.name} — {c.total}</li>
                        ))}
                    </ul>
                </div>
            </section>
        </div>
    );
};

export default SalesDashboard;