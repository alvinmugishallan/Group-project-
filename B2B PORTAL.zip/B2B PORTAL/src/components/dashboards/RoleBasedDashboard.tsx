import React, { useEffect, useState } from 'react';
import { get } from '../../services/api';
import CEODashboard from './ceo/CEODashboard';
import ManagerDashboard from './manager/ManagerDashboard';
import SalesDashboard from './sales/SalesDashboard';
import CustomerDashboard from './customer/CustomerDashboard';
import NotificationBar from '../shared/NotificationBar';

type Role = 'ceo' | 'manager' | 'sales' | 'customer' | 'guest';

const RoleBasedDashboard: React.FC = () => {
  const [role, setRole] = useState<Role>('guest');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const data = await get('/auth/me').catch(() => null);
        if (!mounted) return;
        if (data && data.role) setRole(data.role as Role);
        else setRole('customer');
      } catch (e) {
        setRole('guest');
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => {
      mounted = false;
    };
  }, []);

  if (loading) return <div>Loading dashboard...</div>;

  const renderByRole = () => {
    switch (role) {
      case 'ceo':
        return <CEODashboard />;
      case 'manager':
        return <ManagerDashboard />;
      case 'sales':
        return <SalesDashboard />;
      case 'customer':
      default:
        return <CustomerDashboard />;
    }
  };

  return (
    <>
      {/* Show notifications only on the dashboard route */}
      <NotificationBar />
      {renderByRole()}
    </>
  );
};

export default RoleBasedDashboard;
