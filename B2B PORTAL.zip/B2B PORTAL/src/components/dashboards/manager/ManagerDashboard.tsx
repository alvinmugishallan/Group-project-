import React, { useEffect, useState } from 'react';
import { get, post } from '../../../services/api';

interface PendingItem {
  id: string;
  type: string;
  title: string;
  amount?: number;
  submittedBy?: string;
}

const ManagerDashboard: React.FC = () => {
    const [loading, setLoading] = useState(true);
    const [teamSales, setTeamSales] = useState<number | null>(null);
    const [orderProcessingTime, setOrderProcessingTime] = useState<number | null>(null);
    const [inventoryHealth, setInventoryHealth] = useState<string | null>(null);
    const [pending, setPending] = useState<PendingItem[]>([]);

    useEffect(() => {
        let mounted = true;
        (async () => {
            try {
                const data = await get('/manager/overview');
                if (!mounted) return;
                setTeamSales(data.teamSales);
                setOrderProcessingTime(data.orderProcessingTimeHours);
                setInventoryHealth(data.inventoryHealth);
                setPending(data.pendingApprovals || []);
            } catch (e) {
                // ignore
            } finally {
                if (mounted) setLoading(false);
            }
        })();
        return () => { mounted = false; };
    }, []);

    const approve = async (id: string) => {
        try {
            await post('/manager/approve', { id });
            setPending(p => p.filter(x => x.id !== id));
        } catch (e) {
            // TODO: show error
        }
    };

    if (loading) return <div>Loading manager overview...</div>;

    return (
        <div className="manager-dashboard">
            <h1 style={{marginBottom:12}}>Manager Dashboard</h1>

            <section style={{marginBottom:18}}>
                <h2 style={{marginBottom:8}}>Operational Metrics</h2>
                <div className="dashboard-grid">
                    <div className="card-dark">
                        <h3>Team Sales</h3>
                        <div style={{marginTop:8,fontSize:20,fontWeight:800}}>UGX{teamSales ?? '—'}</div>
                    </div>
                    <div className="card-dark">
                        <h3>Order Processing Time (hrs)</h3>
                        <div style={{marginTop:8,fontSize:20,fontWeight:700}}>{orderProcessingTime ?? '—'}</div>
                    </div>
                    <div className="card-dark">
                        <h3>Inventory Health</h3>
                        <div style={{marginTop:8}}>{inventoryHealth ?? '—'}</div>
                    </div>
                </div>
            </section>

            <section style={{marginBottom:18}}>
                <h2 style={{marginBottom:8}}>Pending Approvals</h2>
                <div className="card-dark">
                {pending.length === 0 ? (
                    <div>No pending approvals</div>
                ) : (
                    <ul>
                        {pending.map(p => (
                            <li key={p.id} style={{marginBottom:8}}>
                                <strong>{p.title}</strong> — {p.type} — by {p.submittedBy}
                                <button style={{ marginLeft: 8 }} onClick={() => approve(p.id)}>Approve</button>
                            </li>
                        ))}
                    </ul>
                )}
                </div>
            </section>

            <section style={{marginBottom:18}}>
                <h2 style={{marginBottom:8}}>Quick Actions</h2>
                <div style={{display:'flex',gap:12}}>
                    <div className="card-dark" style={{padding:'12px 16px'}}>Manage Schedule</div>
                    <div className="card-dark" style={{padding:'12px 16px'}}>Review Performance</div>
                </div>
            </section>
        </div>
    );
};

export default ManagerDashboard;