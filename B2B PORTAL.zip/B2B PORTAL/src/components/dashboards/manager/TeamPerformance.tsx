import React from 'react';

const TeamPerformance: React.FC = () => {
    // Sample data for team performance
    const teamData = [
        { name: 'John', sales: 150, target: 200 },
        { name: 'Alvin', sales: 180, target: 200 },
        { name: 'Dian', sales: 120, target: 200 },
        { name: 'Katwika', sales: 200, target: 200 },
        { name: 'Benji', sales: 160, target: 200 },
    ];

    return (
        <div>
            <h2>Team Performance</h2>
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Sales</th>
                        <th>Target</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    {teamData.map((member) => (
                        <tr key={member.name}>
                            <td>{member.name}</td>
                            <td>{member.sales}</td>
                            <td>{member.target}</td>
                            <td>{member.sales >= member.target ? 'Achieved' : 'Not Achieved'}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default TeamPerformance;