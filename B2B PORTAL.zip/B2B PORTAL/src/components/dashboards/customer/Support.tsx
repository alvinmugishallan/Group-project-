import React from 'react';

const Support: React.FC = () => {
    return (
        <div>
            <h2>Support</h2>
            <p>If you need assistance, please contact your account manager:</p>
            <div style={{marginTop: '1rem', padding: '1rem', borderRadius: 8, background: 'var(--card)', border: '1px solid var(--border)'}}>
                <p style={{margin: 0, fontWeight: 700}}>Your account manager: <span style={{fontWeight:600}}>Diana Atugonza</span></p>
                <p style={{margin: '6px 0 0 0'}}>Phone: <a href="tel:+256788509509">+256 788 509 509</a></p>
                <p style={{margin: '6px 0 0 0'}}>Email: <a href="mailto:atugonzadiana@gmail.com">atugonzadiana@gmail.com</a></p>
            </div>
            <p style={{marginTop: '1rem'}}>For emergencies, please reach out to our emergency contact.</p>
        </div>
    );
};

export default Support;