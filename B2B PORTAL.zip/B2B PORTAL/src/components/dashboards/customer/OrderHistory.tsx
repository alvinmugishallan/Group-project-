import React from 'react';

const OrderHistory: React.FC = () => {
    // Sample order history data
    const orders = [
        { id: 1, date: '2023-01-10', status: 'Delivered', total: 'UGX100.00' },
        { id: 2, date: '2023-02-15', status: 'Shipped', total: 'UGX150.00' },
        { id: 3, date: '2023-03-20', status: 'Processed', total: 'UGX200.00' },
    ];

    return (
        <div>
            <h2>Order History</h2>
            <table>
                <thead>
                    <tr>
                        <th>Order ID</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody>
                    {orders.map(order => (
                        <tr key={order.id}>
                            <td>{order.id}</td>
                            <td>{order.date}</td>
                            <td>{order.status}</td>
                            <td>{order.total}</td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default OrderHistory;