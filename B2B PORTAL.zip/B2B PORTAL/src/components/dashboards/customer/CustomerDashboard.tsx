import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import styles from './Dashboard.module.css';
import { get } from '../../../services/api';

const CustomerDashboard: React.FC = () => {
  const [loading, setLoading] = useState(true);
  const [account, setAccount] = useState<any>(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const data = await get('/customer/account');
        if (!mounted) return;
        setAccount(data);
      } catch (e) {
        // ignore
      } finally {
        if (mounted) setLoading(false);
      }
    })();
    return () => { mounted = false; };
  }, []);

  if (loading) return <div>Loading customer data...</div>;

  return (
    <div>
      <div style={{marginBottom:12}}>
        <h1>Customer Dashboard</h1>
        <p>Account summary and recent activity</p>
      </div>

      <div className="dashboard-grid">
        <div className="card-dark">
          <h3>Current Balance</h3>
          <p style={{marginTop:8,fontSize:20,fontWeight:800}}>UGX{account?.currentBalance ?? '—'}</p>
        </div>

        <div className="card-dark">
          <h3>Available Credit</h3>
          <p style={{marginTop:8,fontSize:18}}>UGX{account?.availableCredit ?? '—'}</p>
        </div>

        <div className="card-dark">
          <h3>Next Payment Due</h3>
          <p style={{marginTop:8}}>{account?.nextPaymentDue ?? '—'}</p>
        </div>

        <div className="card-dark">
          <h3>Recent Orders</h3>
          <ul>
            {(account?.recentOrders || []).map((o: any) => (
              <li key={o.id}>{o.id} — {o.date} — UGX{o.total} — {o.status}</li>
            ))}
          </ul>
          <Link to="/products" className={styles.btn}>Order Now</Link>
        </div>
      </div>
    </div>
  );
};

export default CustomerDashboard;