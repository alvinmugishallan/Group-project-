import React, { useEffect, useState } from 'react';
import { get } from '../../../services/api';
import CEOMetrics from './components/CEOMetrics';
import RevenueTrend from './components/RevenueTrend';
import CategoryPerformance from './components/CategoryPerformance';
import SalesByRegion from './components/SalesByRegion';

const CEODashboard: React.FC = () => {
    const [loading, setLoading] = useState(true);
    const [metrics, setMetrics] = useState<any>(null);

    useEffect(() => {
        let mounted = true;
        (async () => {
            try {
                const data = await get('/metrics/ceo');
                if (!mounted) return;
                setMetrics(data);
            } catch (e) {
                // ignore
            } finally {
                if (mounted) setLoading(false);
            }
        })();
        return () => { mounted = false; };
    }, []);

    if (loading) return <div>Loading CEO dashboard...</div>;

    return (
            <div className="ceo-dashboard">
                <h1 style={{marginBottom:12}}>CEO Dashboard</h1>

                <section style={{marginBottom:18}}>
                    <h2 style={{marginBottom:8}}>Key Metrics</h2>
                    <div className="dashboard-grid">
                        {/* metrics cards: CEOMetrics returns a set of small cards; wrap it in a dark card container */}
                        <div className="card-dark">
                            <CEOMetrics data={metrics} />
                        </div>
                        <div className="card-dark metric-card">
                            <h3 style={{margin:0}}>Top Categories</h3>
                            <div style={{marginTop:10}}>
                                <CategoryPerformance data={metrics?.categoryPerformance || []} />
                            </div>
                        </div>
                        <div className="card-dark metric-card">
                            <h3 style={{margin:0}}>Sales By Region</h3>
                            <div style={{marginTop:10}}>
                                <SalesByRegion data={metrics?.salesByRegion || []} />
                            </div>
                        </div>
                    </div>
                </section>

                <section style={{marginBottom:18}}>
                    <h2 style={{marginBottom:8}}>Main Charts</h2>
                    <div className="dashboard-grid">
                        <div className="card-dark chart-wrapper">
                            <RevenueTrend data={metrics?.revenueTrend || []} />
                        </div>
                        <div className="card-dark chart-wrapper">
                            <CategoryPerformance data={metrics?.categoryPerformance || []} />
                        </div>
                        <div className="card-dark chart-wrapper">
                            <SalesByRegion data={metrics?.salesByRegion || []} />
                        </div>
                    </div>
                </section>

                <section style={{marginBottom:18}}>
                    <h2 style={{marginBottom:8}}>Quick Links</h2>
                    <div style={{display:'flex',gap:12}}>
                        <div className="card-dark" style={{padding:'12px 18px'}}>Create Report</div>
                        <div className="card-dark" style={{padding:'12px 18px'}}>Export Data</div>
                        <div className="card-dark" style={{padding:'12px 18px'}}>Invite User</div>
                    </div>
                </section>
            </div>
    );
};

export default CEODashboard;