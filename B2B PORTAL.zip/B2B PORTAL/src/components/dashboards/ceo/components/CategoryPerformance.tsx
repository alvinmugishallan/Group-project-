import React from 'react';

interface Props { data: Array<{ category: string; sales: number }>; }

const CategoryPerformance: React.FC<Props> = ({ data }) => {
  if (!data || data.length === 0) return <div style={{ width: 240 }}>No category data</div>;
  const max = Math.max(...data.map(d => d.sales));
  return (
    <div style={{ width: 240 }}>
      {data.map(d => (
        <div key={d.category} style={{ marginBottom: 8 }}>
          <div style={{ fontSize: 12 }}>{d.category} — {d.sales}</div>
          <div style={{ background: 'var(--border-soft)', height: 10, borderRadius: 4 }}>
            <div style={{ width: `${(d.sales / (max || 1)) * 100}%`, background: 'var(--primary)', height: '100%', borderRadius: 4 }} />
          </div>
        </div>
      ))}
    </div>
  );
};

export default CategoryPerformance;
