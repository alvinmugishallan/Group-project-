import React, { useEffect, useState } from 'react';
import { get } from '../../../../services/api';

interface MetricCardProps {
  title: string;
  value: string | number;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value }) => (
  <div className="metric-card">
    <div className="metric-title">{title}</div>
    <div className="metric-value">{value}</div>
  </div>
);

interface CEOMetricsProps {
  data?: any;
}

export default function CEOMetrics({ data }: CEOMetricsProps) {
  const [metrics, setMetrics] = useState<any[]>([]);

  useEffect(() => {
    if (data) {
      setMetrics([
        { title: 'Total Revenue', value: `UGX${(data.totalRevenue ?? 0).toLocaleString()}` },
        { title: 'Gross Profit', value: `UGX${(data.grossProfit ?? 0).toLocaleString()}` },
        { title: 'Active Customers', value: data.activeCustomers ?? 0 },
        { title: 'Order Volume', value: data.orderVolume ?? 0 },
      ]);
      return;
    }

    let mounted = true;
    (async () => {
      try {
        const fetched = await get('/metrics/ceo');
        if (!mounted) return;
        setMetrics([
          { title: 'Total Revenue', value: `UGX${(fetched.totalRevenue ?? 0).toLocaleString()}` },
          { title: 'Gross Profit', value: `UGX${(fetched.grossProfit ?? 0).toLocaleString()}` },
          { title: 'Active Customers', value: fetched.activeCustomers ?? 0 },
          { title: 'Order Volume', value: fetched.orderVolume ?? 0 },
        ]);
      } catch (e) {
        setMetrics([
          { title: 'Total Revenue', value: 'UGX1,234,567' },
          { title: 'Gross Profit', value: 'UGX456,789' },
          { title: 'Active Customers', value: 1234 },
          { title: 'Order Volume', value: 9876 },
        ]);
      }
    })();
    return () => { mounted = false; };
  }, [data]);

  return (
    <div className="ceo-metrics">
      {metrics.map(m => (
        <MetricCard key={m.title} title={m.title} value={m.value} />
      ))}
    </div>
  );
}
