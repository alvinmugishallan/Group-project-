import React from 'react';

interface Props { data: Array<{ date: string; value: number }>; }

const RevenueTrend: React.FC<Props> = ({ data }) => {
  if (!data || data.length === 0) return <div style={{ width: 300 }}>No revenue data</div>;

  const values = data.map(d => d.value);
  const max = Math.max(...values);
  const min = Math.min(...values);
  const w = 300; const h = 120; const padding = 10;

  const points = data.map((d, i) => {
    const x = padding + (i * (w - padding * 2)) / (data.length - 1);
    const y = h - padding - ((d.value - min) / (max - min || 1)) * (h - padding * 2);
    return `${x},${y}`;
  }).join(' ');

  return (
    <svg width={w} height={h} style={{ background: 'var(--card)', border: '1px solid var(--border)' }}>
      <polyline fill="none" stroke="var(--primary)" strokeWidth={2} points={points} />
      {data.map((d, i) => {
        const x = padding + (i * (w - padding * 2)) / (data.length - 1);
        const y = h - padding - ((d.value - min) / (max - min || 1)) * (h - padding * 2);
        return <circle key={d.date} cx={x} cy={y} r={3} fill="var(--primary-600)" />;
      })}
    </svg>
  );
};

export default RevenueTrend;
