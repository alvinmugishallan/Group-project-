import React from 'react';

interface Props { data: Array<{ region: string; sales: number }>; }

const SalesByRegion: React.FC<Props> = ({ data }) => {
  if (!data || data.length === 0) return <div style={{ width: 200 }}>No region data</div>;
  const total = data.reduce((s, d) => s + d.sales, 0) || 1;
  return (
    <div style={{ width: 200 }}>
      {data.map(d => (
        <div key={d.region} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
          <div>{d.region}</div>
          <div>{Math.round((d.sales / total) * 100)}%</div>
        </div>
      ))}
    </div>
  );
};

export default SalesByRegion;
