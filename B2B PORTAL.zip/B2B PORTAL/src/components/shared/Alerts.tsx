import React, { useEffect, useState } from 'react';
import { get } from '../../services/api';

interface AlertItem {
  id: string;
  message: string;
  type?: 'info' | 'error' | 'success';
}

const Alerts: React.FC = () => {
  const [alerts, setAlerts] = useState<AlertItem[]>([]);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        // If backend supports notifications, call it. Fallback: empty list.
        const data = await get('/notifications').catch(() => []);
        if (!mounted) return;
        setAlerts(data || []);
      } catch (e) {
        // ignore
      }
    })();
    return () => { mounted = false; };
  }, []);

  if (!alerts || alerts.length === 0) return null;

  return (
    <div className="alerts">
      {alerts.map(a => (
        <div key={a.id} className={`alert ${a.type || 'info'}`}>{a.message}</div>
      ))}
    </div>
  );
};

export default Alerts;
