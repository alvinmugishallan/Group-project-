import React from 'react';
import Alerts from './Alerts';

// NotificationBar now renders Alerts (pulled from backend) and can still accept an optional message prop.
interface NotificationProps {
  message?: string;
  type?: 'success' | 'error' | 'info';
}

const NotificationBar: React.FC<NotificationProps> = ({ message = '', type = 'info' }) => {
  return (
    <div className="notificationBar">
      {message && <div className={`notification ${type}`}>{message}</div>}
      <Alerts />
    </div>
  );
};

export default NotificationBar;