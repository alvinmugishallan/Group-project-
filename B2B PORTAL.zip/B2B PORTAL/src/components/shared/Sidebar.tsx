import React, { useEffect, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import styles from './Sidebar.module.css';
import { get } from '../../services/api';
import { gravatarUrl } from '../../utils/gravatar';

interface SidebarProps {
  className?: string;
}

const Sidebar: React.FC<SidebarProps> = ({ className }) => {
  const [user, setUser] = useState<{ name?: string; email?: string; role?: string } | null>(null);

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const data = await get('/auth/me').catch(() => null);
        if (!mounted) return;
        setUser(data || null);
      } catch (e) {
        // ignore
      }
    })();
  // no client-side avatar upload persistence – use gravatar or server-stored avatar
    return () => { mounted = false; };
  }, []);

  // upload removed — avatar persistence can be implemented server-side if desired

  const navigate = useNavigate();
  const logout = () => {
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    navigate('/login');
  };

  const name = user?.name || 'John Smith';
  const roleText = user?.role || 'Admin';
  // const initials used previously for placeholder; now we prefer gravatar or uploaded avatar
  const gravatar = gravatarUrl(user?.email);

  return (
    <aside className={`${styles.sidebar} ${className || ''}`}>
      <div className={styles.profile}>
            <img src={gravatar} alt="gravatar" className={styles.avatar} />
        <div>
          <div className={styles.profileName}>{name}</div>
          <div className={styles.profileRole}>{roleText}</div>
        </div>
      </div>
      {/* avatar upload removed; implement server-side upload if cross-device persistence is required */}
      <div className={styles.logo}>
        <h1>Golden Crop Distributors Ltd</h1>
      </div>
  <nav className={styles.nav}>
        <NavLink 
          to="/dashboard" 
          className={({ isActive }) => 
            isActive ? `${styles.link} ${styles.active}` : styles.link
          }
        >
          📊 Dashboard
        </NavLink>
        <NavLink 
          to="/orders" 
          className={({ isActive }) => 
            isActive ? `${styles.link} ${styles.active}` : styles.link
          }
        >
          📦 Orders
        </NavLink>
        <NavLink 
          to="/products" 
          className={({ isActive }) => 
            isActive ? `${styles.link} ${styles.active}` : styles.link
          }
        >
          🛍️ Products
        </NavLink>
        <NavLink 
          to="/support" 
          className={({ isActive }) => 
            isActive ? `${styles.link} ${styles.active}` : styles.link
          }
        >
          💬 Support
        </NavLink>
        <button onClick={logout} className={styles.link} style={{background:'transparent',border:'none',textAlign:'left',cursor:'pointer'}}>🔒 Logout</button>
      </nav>
    </aside>
  );
};

export default Sidebar;