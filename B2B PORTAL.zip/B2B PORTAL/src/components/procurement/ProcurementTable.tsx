import React from 'react';
import { mock, Produce } from '../../services/mock';

const ProcurementTable: React.FC = () => {
  const store = mock.get();
  const rows = store.procurement;

  return (
    <div className="card p-6" style={{marginTop:24}}>
      <div className="flex justify-between items-center">
        <h3 className="h3">Procurement Records</h3>
        <span className="subtle">{rows.length} items</span>
      </div>
      <div className="divider mt-4"/>
      <div style={{overflowX:'auto', marginTop:16}}>
        <table className="table" style={{width:'100%', borderCollapse:'separate', borderSpacing:0}}>
          <thead>
            <tr style={{textAlign:'left', color:'var(--muted)'}}>
              <th style={{padding:'10px 12px'}}>Date</th>
              <th style={{padding:'10px 12px'}}>Name</th>
              <th style={{padding:'10px 12px'}}>Type</th>
              <th style={{padding:'10px 12px'}}>Branch</th>
              <th style={{padding:'10px 12px'}}>Tonnage</th>
              <th style={{padding:'10px 12px'}}>Cost/t</th>
              <th style={{padding:'10px 12px'}}>Dealer</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r: Produce)=> (
              <tr key={r.id} className="surface" style={{borderRadius:12}}>
                <td style={{padding:'10px 12px'}}>{new Date(r.datetime).toLocaleString()}</td>
                <td style={{padding:'10px 12px'}}>{r.name}</td>
                <td style={{padding:'10px 12px'}}>{r.type}</td>
                <td style={{padding:'10px 12px'}}>{r.branch}</td>
                <td style={{padding:'10px 12px'}}>{r.tonnage}</td>
                <td style={{padding:'10px 12px'}}>{r.costPerTonne}</td>
                <td style={{padding:'10px 12px'}}>{r.dealerName}</td>
              </tr>
            ))}
            {rows.length===0 && (
              <tr><td colSpan={7} className="subtle" style={{padding:'12px'}}>No data yet. Add a procurement above.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default ProcurementTable;
