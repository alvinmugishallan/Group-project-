import React, { useState } from 'react';
import { mock } from '../../services/mock';
import { numberRequired, positive, required } from '../../utils/validators';

const ProcurementForm: React.FC = () => {
  const [form, setForm] = useState({
    name: '', type: '', branch: '', tonnage: '', costPerTonne: '', dealerName: '', contact: '', sellingPrice: '', datetime: new Date().toISOString().slice(0,16)
  });
  const [error, setError] = useState<string | null>(null);

  const update = (k: string, v: string) => setForm(s => ({ ...s, [k]: v }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault(); setError(null);
    const errs = [required(form.name), required(form.type), required(form.branch), numberRequired(form.tonnage), numberRequired(form.costPerTonne)];
    if (errs.find(Boolean)) { setError('Please complete required fields with valid numbers.'); return; }
    const tonnage = parseFloat(form.tonnage); const costPerTonne = parseFloat(form.costPerTonne); const sellingPrice = parseFloat(form.sellingPrice||'0');
    const posErr = positive(tonnage) || positive(costPerTonne);
    if (posErr) { setError(posErr); return; }
    mock.addProcurement({
      name: form.name, type: form.type, branch: form.branch, tonnage, costPerTonne, dealerName: form.dealerName, contact: form.contact, sellingPrice, datetime: new Date(form.datetime).toISOString()
    });
    setForm({ name: '', type: '', branch: '', tonnage: '', costPerTonne: '', dealerName: '', contact: '', sellingPrice: '', datetime: new Date().toISOString().slice(0,16)});
  };

  return (
    <div className="card p-6" style={{maxWidth:1200, margin:'0 auto'}}>
      <h2 className="h2">Record Procurement</h2>
      <p className="subtle">Capture new produce received into stock.</p>
      <form className="flex flex-col gap-4 mt-6" onSubmit={submit}>
        {error && <div className="error" role="alert">{error}</div>}
        <div className="flex gap-6">
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="name">Produce name</label>
            <input id="name" className="input" value={form.name} onChange={e=>update('name', e.target.value)} placeholder="e.g., Beans"/>
          </div>
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="type">Type</label>
            <input id="type" className="input" value={form.type} onChange={e=>update('type', e.target.value)} placeholder="e.g., Grain"/>
          </div>
        </div>
        <div className="flex gap-6">
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="branch">Branch</label>
            <input id="branch" className="input" value={form.branch} onChange={e=>update('branch', e.target.value)} placeholder="e.g., Maganjo"/>
          </div>
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="tonnage">Tonnage (t)</label>
            <input id="tonnage" className="input" value={form.tonnage} onChange={e=>update('tonnage', e.target.value)} placeholder="e.g., 10"/>
          </div>
        </div>
        <div className="flex gap-6">
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="costPerTonne">Cost / tonne</label>
            <input id="costPerTonne" className="input" value={form.costPerTonne} onChange={e=>update('costPerTonne', e.target.value)} placeholder="e.g., 250"/>
          </div>
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="sellingPrice">Selling price</label>
            <input id="sellingPrice" className="input" value={form.sellingPrice} onChange={e=>update('sellingPrice', e.target.value)} placeholder="e.g., 300"/>
          </div>
        </div>
        <div className="flex gap-6">
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="dealerName">Dealer name</label>
            <input id="dealerName" className="input" value={form.dealerName} onChange={e=>update('dealerName', e.target.value)} placeholder="e.g., John"/>
          </div>
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="contact">Contact</label>
            <input id="contact" className="input" value={form.contact} onChange={e=>update('contact', e.target.value)} placeholder="e.g., +256..."/>
          </div>
        </div>
        <div className="form-row">
          <label className="subtle" htmlFor="datetime">Date/time</label>
          <input id="datetime" type="datetime-local" className="input" value={form.datetime} onChange={e=>update('datetime', e.target.value)} />
        </div>
        <div className="btn-row">
          <button className="button btn-primary" type="submit">Save procurement</button>
        </div>
      </form>
    </div>
  );
};

export default ProcurementForm;
