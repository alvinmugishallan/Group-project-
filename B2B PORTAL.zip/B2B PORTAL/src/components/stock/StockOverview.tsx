import React from 'react';
import { mock } from '../../services/mock';

const StockOverview: React.FC = () => {
  const store = mock.get();
  const rows = store.stock;
  return (
    <div className="card p-6">
      <h3 className="h3">Stock Overview</h3>
      <div className="divider mt-4"/>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fill, minmax(240px, 1fr))', gap:16, marginTop:16}}>
        {rows.map(s => (
          <div key={s.produceName} className="surface p-4" style={{borderRadius:12}}>
            <div className="flex justify-between items-center">
              <strong>{s.produceName}</strong>
              <span className="badge">Qty: {s.currentQty}t</span>
            </div>
            <div className="subtle mt-4">Last updated: {new Date(s.lastUpdated).toLocaleString()}</div>
          </div>
        ))}
        {rows.length===0 && <div className="subtle">No stock yet. Add procurement records to populate.</div>}
      </div>
    </div>
  );
};

export default StockOverview;
