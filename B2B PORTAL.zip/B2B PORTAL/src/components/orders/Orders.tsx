import React from 'react';
import OrderHistory from '../dashboards/customer/OrderHistory';

const Orders: React.FC = () => {
  return (
    <div>
      <h2>Orders</h2>
      <p>View and manage your orders below.</p>
      <OrderHistory />
    </div>
  );
};

export default Orders;
