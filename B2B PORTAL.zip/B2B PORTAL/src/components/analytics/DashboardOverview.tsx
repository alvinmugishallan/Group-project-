import React, { useMemo } from 'react';
import { mock } from '../../services/mock';
import { Link } from 'react-router-dom';

function currency(n:number){ return new Intl.NumberFormat(undefined,{style:'currency', currency:'USD'}).format(n); }

function sparkline(values:number[], width=220, height=60, stroke='var(--primary)'){
  if(values.length===0) return null;
  const max = Math.max(...values); const min = Math.min(...values);
  const norm = values.map((v,i)=>{
    const x = (i/(values.length-1)) * (width-2) + 1;
    const y = height - ((v - min) / (max - min || 1)) * (height-2) - 1;
    return `${x},${y}`;
  }).join(' ');
  return (
    <svg width={width} height={height} style={{display:'block'}}>
      <polyline fill="none" stroke={stroke} strokeWidth="2" points={norm} />
    </svg>
  );
}

const DashboardOverview: React.FC = () => {
  const store = mock.get();
  const totalSales = store.sales.reduce((a,b)=>a + b.total, 0);
  const totalProcCost = store.procurement.reduce((a,b)=>a + (b.tonnage * b.costPerTonne), 0);
  const openCredit = store.credit.filter(c=>c.status!=='paid').reduce((a,b)=>a + b.amount, 0);

  const kpis = [
    { label: 'Total Sales', value: currency(totalSales) },
    { label: 'Procurement Cost', value: currency(totalProcCost) },
    { label: 'Open Credit', value: currency(openCredit) },
    { label: 'Stock Items', value: String(store.stock.length) },
  ];

  const salesSeries = useMemo(()=> store.sales.slice(0,12).reverse().map(s=>s.total), [store.sales]);
  const procSeries = useMemo(()=> store.procurement.slice(0,12).reverse().map(p=>p.tonnage * p.costPerTonne), [store.procurement]);

  type Activity = { ts: number; text: string };
  const activity: Activity[] = useMemo(()=>{
    const A: Activity[] = [];
    for(const p of store.procurement){ A.push({ ts: new Date(p.datetime).getTime(), text: `Procured ${p.name} ${p.tonnage}t @ ${p.branch}` }); }
    for(const s of store.sales){ A.push({ ts: new Date(s.datetime).getTime(), text: `Sold ${s.produceName} ${s.tonnage}t to ${s.buyerName||'buyer'}` }); }
    for(const c of store.credit){ A.push({ ts: new Date(c.createdAt).getTime(), text: `Credit ${c.produceName} ${c.tonnage}t to ${c.buyer.name} (due ${new Date(c.dueDate).toLocaleDateString()})` }); }
    return A.sort((a,b)=>b.ts-a.ts).slice(0,10);
  }, [store]);

  return (
    <div className="container">
      <div className="card p-6">
        <div className="flex justify-between items-center">
          <h2 className="h2">Overview</h2>
          <div className="flex gap-3">
            <Link className="button btn-ghost" to="/procurement">Add Procurement</Link>
            <Link className="button btn-ghost" to="/sales">Record Sale</Link>
            <Link className="button btn-ghost" to="/credit-sales">Credit Sale</Link>
          </div>
        </div>
        <div className="divider mt-4"/>
        <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(220px, 1fr))', gap:16, marginTop:16}}>
          {kpis.map(k => (
            <div key={k.label} className="surface p-4" style={{borderRadius:12}}>
              <div className="subtle">{k.label}</div>
              <div className="h2" style={{marginTop:6}}>{k.value}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit, minmax(280px, 1fr))', gap:16, marginTop:16}}>
        <div className="card p-6">
          <div className="flex justify-between items-center">
            <strong>Sales Trend</strong>
            <span className="subtle">last {salesSeries.length} rec</span>
          </div>
          <div className="mt-4">
            {sparkline(salesSeries, 400, 80, 'var(--accent)')}
          </div>
        </div>
        <div className="card p-6">
          <div className="flex justify-between items-center">
            <strong>Procurement Trend</strong>
            <span className="subtle">last {procSeries.length} rec</span>
          </div>
          <div className="mt-4">
            {sparkline(procSeries, 400, 80, 'var(--primary)')}
          </div>
        </div>
      </div>

      <div style={{display:'grid', gridTemplateColumns:'2fr 1fr', gap:16, marginTop:16}}>
        <div className="card p-6">
          <div className="flex justify-between items-center">
            <strong>Recent activity</strong>
            <Link to="/procurement" className="a">View all</Link>
          </div>
          <div className="divider mt-4"/>
          <ul style={{listStyle:'none', padding:0, marginTop:12}}>
            {activity.map((a,i)=> (
              <li key={i} className="surface p-4" style={{borderRadius:12, marginBottom:12}}>
                <div>{a.text}</div>
                <div className="subtle" style={{fontSize:12}}>{new Date(a.ts).toLocaleString()}</div>
              </li>
            ))}
            {activity.length===0 && <li className="subtle">No activity yet. Add records to see updates here.</li>}
          </ul>
        </div>
        <div className="card p-6">
          <strong>Quick links</strong>
          <div className="divider mt-4"/>
          <div className="flex flex-col gap-4 mt-4">
            <Link className="button btn-primary" to="/procurement">Record Procurement</Link>
            <Link className="button btn-primary" to="/sales">Record Sale</Link>
            <Link className="button btn-primary" to="/credit-sales">Record Credit Sale</Link>
            <Link className="button btn-ghost" to="/stock">View Stock</Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardOverview;
