import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../../services/api';
import styles from './Auth.module.css';

const SignUp: React.FC = () => {
  const [form, setForm] = useState({ companyName: '', contactName: '', email: '', phone: '', password: '', confirm: '' });
  const [error, setError] = useState<string | null>(null);
  const nav = useNavigate();

  const update = (k: string, v: string) => setForm(s => ({ ...s, [k]: v }));

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!form.companyName || !form.email || !form.password) {
      setError('Please complete the required fields.');
      return;
    }
    if (form.password !== form.confirm) {
      setError('Passwords do not match.');
      return;
    }
    try {
      await api.post('/auth/signup', { email: form.email, password: form.password, companyName: form.companyName });
      nav('/login');
    } catch (err: any) {
      setError(err?.response?.data?.message || 'Signup failed');
    }
  };

  return (
    <div className={styles.authContainer}>
      <div className={styles.authCard}>
        <div className={styles.authLeft}>
          <div className={styles.brand}>Golden Crop Distributors Ltd</div>
          <h2 className={styles.authTitle}>Create an account</h2>
          <p className={styles.authSubtitle}>Register your company to access orders, catalogs and analytics.</p>

          <form className={styles.authForm} onSubmit={submit} noValidate>
            {error && <div role="alert" style={{ color: 'crimson', fontWeight: 700 }}>{error}</div>}

            <div className={styles.formGroup}>
              <label htmlFor="companyName">Company name</label>
              <input id="companyName" className={styles.input} value={form.companyName} onChange={e => update('companyName', e.target.value)} required />
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="contactName">Contact person</label>
              <input id="contactName" className={styles.input} value={form.contactName} onChange={e => update('contactName', e.target.value)} />
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="email">Work email</label>
              <input id="email" className={styles.input} type="email" value={form.email} onChange={e => update('email', e.target.value)} required />
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="phone">Phone</label>
              <input id="phone" className={styles.input} value={form.phone} onChange={e => update('phone', e.target.value)} />
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="password">Password</label>
              <input id="password" className={styles.input} type="password" value={form.password} onChange={e => update('password', e.target.value)} required />
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="confirm">Confirm password</label>
              <input id="confirm" className={styles.input} type="password" value={form.confirm} onChange={e => update('confirm', e.target.value)} required />
            </div>

            <div className={styles.controls}>
              <button className={styles.authButton} type="submit">Create account</button>
              <Link to="/login" className={styles.smallLink}>Already have an account?</Link>
            </div>
          </form>
        </div>

        <aside className={styles.sidePanel}>
          <h3>Why register?</h3>
          <p>Easy order tracking, team access control and tailored pricing. Get started in minutes.</p>
          <Link to="/login" className={styles.smallLink}>Sign in</Link>
        </aside>
      </div>
    </div>
  );
};

export default SignUp;