import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../../services/api';
import styles from './Auth.module.css';

const Login: React.FC = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState<string | null>(null);
  const nav = useNavigate();

  const onSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    try {
      const { data } = await api.post('/auth/login', { email, password });
      localStorage.setItem('accessToken', data.accessToken);
      if (data.refreshToken) localStorage.setItem('refreshToken', data.refreshToken);
      nav('/dashboard');
    } catch (err: any) {
      setError(err?.response?.data?.message || 'Login failed');
    }
  };

  return (
    <div className={styles.authContainer}>
      <div className={styles.authCard}>
        <div className={styles.authLeft}>
          <div className={styles.brand}>Golden Crop Distributors Ltd</div>
          <h2 className={styles.authTitle}>Welcome back</h2>
          <p className={styles.authSubtitle}>Sign in to access your dashboard and management tools.</p>

          <form onSubmit={onSubmit} className={styles.authForm} noValidate>
            {error && <div role="alert" style={{ color: 'crimson', fontWeight: 700 }}>{error}</div>}
            <div className={styles.formGroup}>
              <label htmlFor="email">Email</label>
              <input id="email" className={styles.input} type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@company.com" required />
            </div>

            <div className={styles.formGroup}>
              <label htmlFor="password">Password</label>
              <input id="password" className={styles.input} type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" required />
            </div>

            <div className={styles.controls}>
              <button className={styles.authButton} type="submit">Sign in</button>
              <Link to="/forgot-password" className={styles.smallLink}>Forgot?</Link>
            </div>
          </form>
        </div>

        <aside className={styles.sidePanel}>
          <h3 style={{ marginTop: 0 }}>New here?</h3>
          <p>Create an account to manage purchases, track orders and collaborate with your team.</p>
          <Link to="/signup" className={styles.smallLink}>Create an account</Link>
        </aside>
      </div>
    </div>
  );
};

export default Login;