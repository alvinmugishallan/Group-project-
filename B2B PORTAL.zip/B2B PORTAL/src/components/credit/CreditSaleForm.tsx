import React, { useState } from 'react';
import { mock } from '../../services/mock';
import { numberRequired, positive, required, phone as phoneV } from '../../utils/validators';

const CreditSaleForm: React.FC = () => {
  const [form, setForm] = useState({
    buyerName:'', nationalId:'', location:'', phone:'', produceName:'', tonnage:'', amount:'', dueDate: new Date().toISOString().slice(0,10)
  });
  const [error, setError] = useState<string|null>(null);
  const update = (k:string, v:string) => setForm(s=>({...s,[k]:v}));

  const submit = (e: React.FormEvent) => {
    e.preventDefault(); setError(null);
    const errs = [required(form.buyerName), required(form.produceName), numberRequired(form.tonnage), numberRequired(form.amount)];
    if (errs.find(Boolean)) { setError('Please fill required fields with valid numbers.'); return; }
    const phoneErr = phoneV(form.phone); if (phoneErr) { setError(phoneErr); return; }
    const tonnage = parseFloat(form.tonnage); const amount = parseFloat(form.amount);
    const posErr = positive(tonnage) || positive(amount); if (posErr) { setError(posErr); return; }
    mock.addCredit({ buyer: { name: form.buyerName, nationalId: form.nationalId, location: form.location, phone: form.phone }, produceName: form.produceName, tonnage, amount, dueDate: new Date(form.dueDate).toISOString() });
    setForm({ buyerName:'', nationalId:'', location:'', phone:'', produceName:'', tonnage:'', amount:'', dueDate: new Date().toISOString().slice(0,10)});
  };

  return (
    <div className="card p-6" style={{maxWidth:1200, margin:'0 auto'}}>
      <h2 className="h2">Record Credit Sale</h2>
      <p className="subtle">Capture a credit transaction with buyer details.</p>
      <form className="flex flex-col gap-4 mt-6" onSubmit={submit}>
        {error && <div className="error" role="alert">{error}</div>}
        <div className="flex gap-6">
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="buyerName">Buyer name</label>
            <input id="buyerName" className="input" value={form.buyerName} onChange={e=>update('buyerName', e.target.value)} />
          </div>
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="nationalId">National ID</label>
            <input id="nationalId" className="input" value={form.nationalId} onChange={e=>update('nationalId', e.target.value)} />
          </div>
        </div>
        <div className="flex gap-6">
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="location">Location</label>
            <input id="location" className="input" value={form.location} onChange={e=>update('location', e.target.value)} />
          </div>
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="phone">Phone</label>
            <input id="phone" className="input" value={form.phone} onChange={e=>update('phone', e.target.value)} />
          </div>
        </div>
        <div className="flex gap-6">
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="produceName">Produce name</label>
            <input id="produceName" className="input" value={form.produceName} onChange={e=>update('produceName', e.target.value)} />
          </div>
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="tonnage">Tonnage (t)</label>
            <input id="tonnage" className="input" value={form.tonnage} onChange={e=>update('tonnage', e.target.value)} />
          </div>
        </div>
        <div className="flex gap-6">
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="amount">Amount</label>
            <input id="amount" className="input" value={form.amount} onChange={e=>update('amount', e.target.value)} />
          </div>
          <div className="form-row" style={{flex:1}}>
            <label className="subtle" htmlFor="dueDate">Due date</label>
            <input id="dueDate" type="date" className="input" value={form.dueDate} onChange={e=>update('dueDate', e.target.value)} />
          </div>
        </div>
        <div className="btn-row">
          <button className="button btn-primary" type="submit">Save credit sale</button>
        </div>
      </form>
    </div>
  );
};

export default CreditSaleForm;
