import React from 'react';
import { mock, CreditSale } from '../../services/mock';

const statusColor: Record<CreditSale['status'], string> = {
  due: 'badge', overdue: 'badge', paid: 'badge'
};

const CreditSalesTable: React.FC = () => {
  const store = mock.get();
  const rows = store.credit;

  return (
    <div className="card p-6" style={{marginTop:24}}>
      <div className="flex justify-between items-center">
        <h3 className="h3">Credit Sales</h3>
        <span className="subtle">{rows.length} items</span>
      </div>
      <div className="divider mt-4"/>
      <div style={{overflowX:'auto', marginTop:16}}>
        <table style={{width:'100%', borderCollapse:'separate', borderSpacing:0}}>
          <thead>
            <tr style={{textAlign:'left', color:'var(--muted)'}}>
              <th style={{padding:'10px 12px'}}>Created</th>
              <th style={{padding:'10px 12px'}}>Buyer</th>
              <th style={{padding:'10px 12px'}}>Produce</th>
              <th style={{padding:'10px 12px'}}>Tonnage</th>
              <th style={{padding:'10px 12px'}}>Amount</th>
              <th style={{padding:'10px 12px'}}>Due</th>
              <th style={{padding:'10px 12px'}}>Status</th>
              <th style={{padding:'10px 12px'}}>Actions</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r)=> (
              <tr key={r.id} className="surface" style={{borderRadius:12}}>
                <td style={{padding:'10px 12px'}}>{new Date(r.createdAt).toLocaleString()}</td>
                <td style={{padding:'10px 12px'}}>{r.buyer.name}</td>
                <td style={{padding:'10px 12px'}}>{r.produceName}</td>
                <td style={{padding:'10px 12px'}}>{r.tonnage}</td>
                <td style={{padding:'10px 12px'}}>{r.amount}</td>
                <td style={{padding:'10px 12px'}}>{new Date(r.dueDate).toLocaleDateString()}</td>
                <td style={{padding:'10px 12px'}}><span className={statusColor[r.status]}>{r.status}</span></td>
                <td style={{padding:'10px 12px'}}>
                  {r.status !== 'paid' && (
                    <button className="button btn-ghost" onClick={()=>mock.markCreditPaid(r.id)}>Mark paid</button>
                  )}
                </td>
              </tr>
            ))}
            {rows.length===0 && (
              <tr><td colSpan={8} className="subtle" style={{padding:'12px'}}>No data yet. Add a credit sale above.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default CreditSalesTable;
