# B2B Backend (MySQL + TypeORM)

Development:
1. Copy `.env.example` to `.env` and adjust if needed.
2. From backend folder run:
   docker-compose up --build
   # This starts MySQL and the backend. The backend runs in dev mode (ts-node-dev).

3. API:
   - POST /api/auth/signup
   - POST /api/auth/login
   - POST /api/auth/refresh
   - GET /api/auth/me
   - GET /api/products

Notes:
- TypeORM synchronize=true is enabled for dev. Use migrations for production.
- Change JWT secrets for production.