import 'reflect-metadata';
import { DataSource } from 'typeorm';
import { User } from './entities/User';
import { Product } from './entities/Product';
import dotenv from 'dotenv';
dotenv.config();

export const AppDataSource = new DataSource({
  type: 'mysql',
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3307),
  username: process.env.DB_USER || 'b2buser',
  password: process.env.DB_PASSWORD || 'b2bpass',
  database: process.env.DB_NAME || 'b2b',
  synchronize: true,
  logging: false,
  entities: [User, Product],
});
