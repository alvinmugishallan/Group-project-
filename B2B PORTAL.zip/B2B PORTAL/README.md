# Golden Crop Distributors Ltd — Frontend

This repository contains the frontend application for Golden Crop Distributors Ltd. It's a React + TypeScript single-page app with role-based dashboards (Customer, Sales, Manager, CEO), product and order management UIs, and an API client wired for a companion backend.

This README covers how to run the frontend locally, the minimal environment variables required, where the backend lives, and a few notes on theming and branding.

## Quick start — frontend

Requirements
- Node.js 16+ and npm

Run locally
1. Install dependencies:

```powershell
cd 'c:\Users\USER\Desktop\PROJECT 2\b2b-portal'
npm install
```

2. Start the dev server:

```powershell
npm start
```

The app will open at http://localhost:3000 by default. Ensure the backend API is running (see next section) and that `REACT_APP_API_BASE_URL` points to it if you're not using a proxy.

Build for production

```powershell
npm run build
```

## Backend (overview)

This project includes a companion backend inside the `backend/` folder (Node + Express + TypeORM + MySQL). You can run it via Docker Compose or locally.

Run with Docker Compose (recommended for quick boot):

```powershell
cd 'c:\Users\USER\Desktop\PROJECT 2\b2b-portal\backend'
docker compose up -d
```

Run locally (dev)

1. Create a `.env` in `backend/` based on `backend/.env.example`.
2. Install and run:

```powershell
cd 'c:\Users\USER\Desktop\PROJECT 2\b2b-portal\backend'
npm install
npm run dev
```

Common backend env variables (examples)

```
PORT=5000
DB_HOST=localhost
DB_USER=b2buser
DB_PASSWORD=b2bpass
DB_NAME=b2b
JWT_ACCESS_SECRET=replace_me
JWT_REFRESH_SECRET=replace_me
```

The backend exposes endpoints under `/api`, including `/api/auth/*`, `/api/seed` (for demo data), `/api/products`, `/api/orders`, and analytics routes used by the dashboards.

## Project structure (directory tree)

Below is a high-level directory tree and short explanation of the main folders and files in this repository.

```
b2b-portal/
	backend/                # Companion backend (Node + Express + TypeORM + MySQL)
		Dockerfile
		docker-compose.yml
		src/
			index.ts
			data-source.ts       # TypeORM data source configuration
			entities/            # TypeORM entity definitions (Product, User, ...)
			routes/              # Express route handlers (auth, products, sales, seed, ...)
		package.json
	public/                 # Static html served by the frontend (index.html)
	src/                    # React + TypeScript frontend source
		index.tsx
		App.tsx
		index.css             # Global CSS variables / theme tokens (light-cool theme)
		components/
			auth/               # Login, SignUp, auth-related UI
			shared/             # Header, Sidebar, NotificationBar, common UI pieces
			dashboards/         # Role-based dashboard pages (ceo, manager, sales, customer)
			products/           # Products page and styles
			sales/, orders/, stock/, procurement/ # feature areas
		services/             # API client, auth helpers, and mock data (src/services/api.ts)
		store/                # Redux / context store setup and reducers
		utils/                # Helper utilities (gravatar, validators, helpers)
	README.md
	BACKEND_INTEGRATION.md
```

Notes on important parts:

- `src/index.css` defines the theme tokens (colors, shadows, spacing). Edit this file to tweak the light-cool palette used across the app.
- `src/components/shared/Sidebar.tsx` and `src/layouts/DashboardLayout.module.css` contain the responsive layout logic that switches the sidebar into a top navigation bar for various viewport widths.
- `backend/docker-compose.yml` creates a named volume (usually `db-data`) that persists MySQL data. Use `docker compose down -v` carefully — it will remove that volume and your DB data unless you've backed it up.

## Frontend environment

Set the API base URL in a `.env` at the project root when required:

```
REACT_APP_API_BASE_URL=http://localhost:5000
```

The frontend's axios client (`src/services/api.ts`) will use this value if present.

## Theming & Branding

- The app uses CSS variables defined in `src/index.css` (root `:root`) for colors, shadows and spacing. To tweak the theme, edit the variables in that file.
- I changed the visible brand strings to "Golden Crop Distributors Ltd" in the UI components. Internal identifiers and DB names (for example `b2b` in Docker and package.json) were left unchanged to avoid breaking configs — let me know if you want them renamed as well.

## Seed data

If the backend exposes a seed route (`/api/seed`) you can call it (or run the backend seed script) to populate demo users, products, and orders. Check `backend/README.md` for backend-specific seeding instructions.

## Development notes

- The sidebar switches to a top navigation bar on narrow and wide viewports. See `src/layouts/DashboardLayout.module.css` and `src/components/shared/Sidebar.module.css` for the responsive breakpoints.
- Avatar uploads are currently client-side disabled; the sidebar uses Gravatar fallback. If you want cross-device avatar persistence I can add a backend upload endpoint and wire it up.
- Charts and inline SVGS use CSS variables where possible; some components still include inline colors — I can convert remaining inline hex colors to variables on request.

## Contributing

1. Fork or branch from `main`.
2. Run the app locally and open a pull request with your changes.

