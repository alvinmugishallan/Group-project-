# Backend Integration Guide — Golden Crop Distributors Ltd

This document explains how to add a backend to the Golden Crop Distributors Ltd frontend. It covers recommended architecture, example Express + TypeScript server skeleton, API endpoints to implement, frontend integration (axios + env/proxy), auth & tokens, DB & Docker, and common tips.

> Assumes your frontend is in `c:\Users\USER\Desktop\PROJECT 2\b2b-portal\` and uses `src/services/api.ts` (axios).

---

## Quick summary

- Recommended stack (minimal): Node.js + Express + TypeScript + PostgreSQL (or MongoDB).
- Auth: JWT (access + refresh) with bcrypt for password hashing.
- Frontend integration: use env var `REACT_APP_API_BASE_URL` and axios interceptors for auth.
- Dev: run backend on `http://localhost:5000` and use CRA proxy or direct env URL.
- Production: use HTTPS, secure cookies or Authorization header; store secrets in env.

---

## 1. API surface (suggested endpoints)

Authentication
- POST /api/auth/signup — create account
- POST /api/auth/login — returns { accessToken, refreshToken, user }
- POST /api/auth/refresh — refresh access token
- POST /api/auth/logout — revoke token

Customers / Users
- GET /api/users/me
- GET /api/users/:id

Products
- GET /api/products
- GET /api/products/:id
- POST /api/products
- PUT /api/products/:id
- DELETE /api/products/:id

Orders
- GET /api/orders
- POST /api/orders
- GET /api/orders/:id
- PUT /api/orders/:id

Support / Tickets
- GET /api/support
- POST /api/support

Analytics (protected)
- GET /api/analytics/overview

---

## 2. Environment variables (.env)

Frontend (.env)
- REACT_APP_API_BASE_URL=http://localhost:5000

Backend (.env)
- PORT=5000
- DATABASE_URL=postgres://user:password@db:5432/b2b
- JWT_ACCESS_SECRET=your_access_secret
- JWT_REFRESH_SECRET=your_refresh_secret
- NODE_ENV=development

---

## 3. Frontend changes (required)

1. Add env variable in project root `.env`:
```
REACT_APP_API_BASE_URL=http://localhost:5000
```

2. Update `src/services/api.ts` to use env var and add interceptors (example):

```typescript
// filepath: c:\Users\USER\Desktop\PROJECT 2\b2b-portal\src\services\api.ts
import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000';

const client = axios.create({
  baseURL: API_BASE_URL,
  timeout: 10000,
});

// Attach token automatically (read from localStorage or from a store)
client.interceptors.request.use((config) => {
  const token = localStorage.getItem('accessToken');
  if (token && config.headers) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

// Simple response interceptor to catch 401 and attempt refresh
client.interceptors.response.use(
  (res) => res,
  async (err) => {
    const originalRequest = err.config;
    if (err.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      const refreshToken = localStorage.getItem('refreshToken');
      if (refreshToken) {
        try {
          const { data } = await axios.post(`${API_BASE_URL}/api/auth/refresh`, { token: refreshToken });
          localStorage.setItem('accessToken', data.accessToken);
          originalRequest.headers.Authorization = `Bearer ${data.accessToken}`;
          return client(originalRequest);
        } catch (refreshErr) {
          // logout flow
          localStorage.removeItem('accessToken');
          localStorage.removeItem('refreshToken');
          window.location.href = '/login';
          return Promise.reject(refreshErr);
        }
      }
    }
    return Promise.reject(err);
  }
);

export default client;
```